﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.Net;
using System.Net.Sockets;

#endregion

namespace QuoteOfTheDay
{
	partial class QuoteForm : Form
	{
		public QuoteForm()
		{
			InitializeComponent();
		}

		private void OnGetQuote(object sender, EventArgs e)
		{
			statusStrip.Text = "";
			string server = textHostname.Text;
			try
			{
				int port = Convert.ToInt32(textPortNumber.Text);
			}
			catch (FormatException ex)
			{
				statusStrip.Text = ex.Message;
				return;
			}
			TcpClient client = new TcpClient();
			NetworkStream stream = null;
			try
			{
				client.Connect(textHostname.Text,
							   Convert.ToInt32(textPortNumber.Text));
				stream = client.GetStream();
				byte[] buffer = new Byte[1024];
				int received = stream.Read(buffer, 0, 1024);
				if (received <= 0)
				{
					statusStrip.Text = "Read failed";
					return;
				}
				textQuote.Text = Encoding.Unicode.GetString(buffer);
			}
			catch (SocketException ex)
			{
				statusStrip.Text = ex.Message;
			}
			finally
			{
				if (stream != null)
					stream.Close();

				if (client.Connected)
					client.Close();
			}

		}
	}
}