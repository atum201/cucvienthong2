﻿namespace QuoteOfTheDay
{
	partial class QuoteForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.textHostname = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textPortNumber = new System.Windows.Forms.TextBox();
			this.textQuote = new System.Windows.Forms.TextBox();
			this.buttonQuote = new System.Windows.Forms.Button();
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			this.SuspendLayout();
// 
// label1
// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 28);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(59, 14);
			this.label1.TabIndex = 0;
			this.label1.Text = "Hostname:";
// 
// textHostname
// 
			this.textHostname.Location = new System.Drawing.Point(104, 28);
			this.textHostname.Name = "textHostname";
			this.textHostname.TabIndex = 1;
			this.textHostname.Text = "localhost";
// 
// label2
// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(246, 27);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(28, 14);
			this.label2.TabIndex = 2;
			this.label2.Text = "Port:";
// 
// textPortNumber
// 
			this.textPortNumber.Location = new System.Drawing.Point(299, 28);
			this.textPortNumber.Name = "textPortNumber";
			this.textPortNumber.Size = new System.Drawing.Size(67, 20);
			this.textPortNumber.TabIndex = 3;
			this.textPortNumber.Text = "4567";
// 
// textQuote
// 
			this.textQuote.AutoSize = false;
			this.textQuote.Location = new System.Drawing.Point(13, 74);
			this.textQuote.Multiline = true;
			this.textQuote.Name = "textQuote";
			this.textQuote.Size = new System.Drawing.Size(353, 119);
			this.textQuote.TabIndex = 4;
// 
// buttonQuote
// 
			this.buttonQuote.Location = new System.Drawing.Point(13, 200);
			this.buttonQuote.Name = "buttonQuote";
			this.buttonQuote.Size = new System.Drawing.Size(353, 45);
			this.buttonQuote.TabIndex = 5;
			this.buttonQuote.Text = "Get Quote";
			this.buttonQuote.Click += new System.EventHandler(this.OnGetQuote);
// 
// statusStrip
// 
			this.statusStrip.Location = new System.Drawing.Point(0, 0);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Padding = new System.Windows.Forms.Padding(0, 0, 12, 0);;
			this.statusStrip.TabIndex = 0;
			this.statusStrip.Text = "statusStrip1";
// 
// QuoteForm
// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(383, 278);
			this.Controls.Add(this.buttonQuote);
			this.Controls.Add(this.textQuote);
			this.Controls.Add(this.textPortNumber);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textHostname);
			this.Controls.Add(this.label1);
			this.Name = "QuoteForm";
			this.Text = "Quote of the Day";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textHostname;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textPortNumber;
		private System.Windows.Forms.TextBox textQuote;
		private System.Windows.Forms.Button buttonQuote;
		private System.Windows.Forms.StatusStrip statusStrip;
	}
}

