﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Wrox.ProCSharp.WinServices
{
	class Program
	{
		static void Main(string[] args)
		{
			QuoteServer qs = new QuoteServer(@"c:\ProCSharp\WindowsServices\quotes.txt",
											  4567);
			qs.Start();
			Console.WriteLine("Hit return to exit");
			Console.ReadLine();
			qs.Stop();

		}
	}
}
