﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace Wrox.ProCSharp.WindowsServices
{
	partial class EventListenerForm : Form
	{
		public EventListenerForm()
		{
			InitializeComponent();
		}

		private void OnExit(object sender, EventArgs e)
		{
			Application.Exit();
		}

		protected void OnEntryWritten(object sender,
   System.Diagnostics.EntryWrittenEventArgs e)
		{
			DateTime time = e.Entry.TimeGenerated;
			string message = e.Entry.Message;
			listBoxEvents.Items.Add(time + " " + message);
		}

	}
}