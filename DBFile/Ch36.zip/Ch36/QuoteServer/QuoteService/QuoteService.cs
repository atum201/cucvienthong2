﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;

#endregion

namespace Wrox.ProCSharp.WinServices
{
	public partial class QuoteService : ServiceBase
	{
		private QuoteServer quoteServer;

		public QuoteService()
		{
			InitializeComponent();
		}

		protected override void OnStart(string[] args)
		{
			try
			{
				quoteServer = new QuoteServer(@"c:\ProCSharp\WindowsServices\quotes.txt",
											  5678);
				quoteServer.Start();
			}
			catch (Exception ex)
			{
				EventLog.WriteEntry("Quote Service", "Error starting: " + ex.Message, EventLogEntryType.Error);
				throw;
			}

		}

		protected override void OnStop()
		{
			quoteServer.Stop();
			EventLog.WriteEntry("Quote Service", "QuoteService stopped");
		}

		protected override void OnPause()
		{
			quoteServer.Suspend();
			EventLog.WriteEntry("Quote Service", "QuoteService paused");
		}
		protected override void OnContinue()
		{
			quoteServer.Resume();
			EventLog.WriteEntry("Quote Service", "QuoteService continued");
		}
		protected override void OnShutdown()
		{
			OnStop();
		}
		public const int commandRefresh = 128;
		protected override void OnCustomCommand(int command)
		{
			switch (command)
			{
				case commandRefresh:
					quoteServer.RefreshQuotes();
					EventLog.WriteEntry("Quote Service", "QuoteService - Refreshed quotes");
					break;
				default:
					break;
			}
		}

	}
}
