﻿namespace ServiceControl
{
	partial class ServiceControlForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.listBoxServices = new System.Windows.Forms.ListBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.textDisplayName = new System.Windows.Forms.TextBox();
			this.textServiceStatus = new System.Windows.Forms.TextBox();
			this.textServiceType = new System.Windows.Forms.TextBox();
			this.textServiceName = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
			this.buttonStart = new System.Windows.Forms.Button();
			this.buttonStop = new System.Windows.Forms.Button();
			this.buttonPause = new System.Windows.Forms.Button();
			this.buttonContinue = new System.Windows.Forms.Button();
			this.buttonRefresh = new System.Windows.Forms.Button();
			this.buttonExit = new System.Windows.Forms.Button();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.tableLayoutPanel3.SuspendLayout();
			this.SuspendLayout();
// 
// splitContainer1
// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
// 
// Panel1
// 
			this.splitContainer1.Panel1.Controls.Add(this.listBoxServices);
// 
// Panel2
// 
			this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
			this.splitContainer1.Size = new System.Drawing.Size(447, 265);
			this.splitContainer1.SplitterDistance = 160;
			this.splitContainer1.TabIndex = 0;
			this.splitContainer1.Text = "splitContainer1";
// 
// listBoxServices
// 
			this.listBoxServices.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBoxServices.FormattingEnabled = true;
			this.listBoxServices.Location = new System.Drawing.Point(0, 0);
			this.listBoxServices.Name = "listBoxServices";
			this.listBoxServices.Size = new System.Drawing.Size(160, 264);
			this.listBoxServices.TabIndex = 0;
			this.listBoxServices.SelectedIndexChanged += new System.EventHandler(this.OnSelectedIndexChanged);
// 
// tableLayoutPanel1
// 
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 134F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(283, 265);
			this.tableLayoutPanel1.TabIndex = 0;
// 
// tableLayoutPanel2
// 
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel2.Controls.Add(this.textDisplayName, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.textServiceStatus, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.textServiceType, 0, 2);
			this.tableLayoutPanel2.Controls.Add(this.textServiceName, 0, 3);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 4;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(277, 128);
			this.tableLayoutPanel2.TabIndex = 2;
// 
// textDisplayName
// 
			this.textDisplayName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textDisplayName.Location = new System.Drawing.Point(3, 3);
			this.textDisplayName.Name = "textDisplayName";
			this.textDisplayName.Size = new System.Drawing.Size(271, 20);
			this.textDisplayName.TabIndex = 7;
// 
// textServiceStatus
// 
			this.textServiceStatus.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textServiceStatus.Location = new System.Drawing.Point(3, 35);
			this.textServiceStatus.Name = "textServiceStatus";
			this.textServiceStatus.Size = new System.Drawing.Size(271, 20);
			this.textServiceStatus.TabIndex = 8;
// 
// textServiceType
// 
			this.textServiceType.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textServiceType.Location = new System.Drawing.Point(3, 67);
			this.textServiceType.Name = "textServiceType";
			this.textServiceType.Size = new System.Drawing.Size(271, 20);
			this.textServiceType.TabIndex = 9;
// 
// textServiceName
// 
			this.textServiceName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textServiceName.Location = new System.Drawing.Point(3, 99);
			this.textServiceName.Name = "textServiceName";
			this.textServiceName.Size = new System.Drawing.Size(271, 20);
			this.textServiceName.TabIndex = 10;
// 
// tableLayoutPanel3
// 
			this.tableLayoutPanel3.ColumnCount = 2;
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel3.Controls.Add(this.buttonStart, 0, 0);
			this.tableLayoutPanel3.Controls.Add(this.buttonStop, 1, 0);
			this.tableLayoutPanel3.Controls.Add(this.buttonPause, 0, 1);
			this.tableLayoutPanel3.Controls.Add(this.buttonContinue, 1, 1);
			this.tableLayoutPanel3.Controls.Add(this.buttonRefresh, 0, 2);
			this.tableLayoutPanel3.Controls.Add(this.buttonExit, 1, 2);
			this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 137);
			this.tableLayoutPanel3.Name = "tableLayoutPanel3";
			this.tableLayoutPanel3.RowCount = 3;
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34F));
			this.tableLayoutPanel3.Size = new System.Drawing.Size(277, 125);
			this.tableLayoutPanel3.TabIndex = 3;
// 
// buttonStart
// 
			this.buttonStart.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonStart.Location = new System.Drawing.Point(3, 3);
			this.buttonStart.Name = "buttonStart";
			this.buttonStart.Size = new System.Drawing.Size(132, 35);
			this.buttonStart.TabIndex = 6;
			this.buttonStart.Text = "Start";
			this.buttonStart.Click += new System.EventHandler(this.buttonCommand_Click);
// 
// buttonStop
// 
			this.buttonStop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonStop.Location = new System.Drawing.Point(141, 3);
			this.buttonStop.Name = "buttonStop";
			this.buttonStop.Size = new System.Drawing.Size(133, 35);
			this.buttonStop.TabIndex = 7;
			this.buttonStop.Text = "Stop";
			this.buttonStop.Click += new System.EventHandler(this.buttonCommand_Click);
// 
// buttonPause
// 
			this.buttonPause.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonPause.Location = new System.Drawing.Point(3, 44);
			this.buttonPause.Name = "buttonPause";
			this.buttonPause.Size = new System.Drawing.Size(132, 35);
			this.buttonPause.TabIndex = 8;
			this.buttonPause.Text = "Pause";
			this.buttonPause.Click += new System.EventHandler(this.buttonCommand_Click);
// 
// buttonContinue
// 
			this.buttonContinue.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonContinue.Location = new System.Drawing.Point(141, 44);
			this.buttonContinue.Name = "buttonContinue";
			this.buttonContinue.Size = new System.Drawing.Size(133, 35);
			this.buttonContinue.TabIndex = 9;
			this.buttonContinue.Text = "Continue";
			this.buttonContinue.Click += new System.EventHandler(this.buttonCommand_Click);
// 
// buttonRefresh
// 
			this.buttonRefresh.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonRefresh.Location = new System.Drawing.Point(3, 85);
			this.buttonRefresh.Name = "buttonRefresh";
			this.buttonRefresh.Size = new System.Drawing.Size(132, 37);
			this.buttonRefresh.TabIndex = 10;
			this.buttonRefresh.Text = "Refresh";
			this.buttonRefresh.Click += new System.EventHandler(this.buttonCommand_Click);
// 
// buttonExit
// 
			this.buttonExit.Dock = System.Windows.Forms.DockStyle.Fill;
			this.buttonExit.Location = new System.Drawing.Point(141, 85);
			this.buttonExit.Name = "buttonExit";
			this.buttonExit.Size = new System.Drawing.Size(133, 37);
			this.buttonExit.TabIndex = 11;
			this.buttonExit.Text = "Exit";
			this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
// 
// ServiceControlForm
// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(447, 265);
			this.Controls.Add(this.splitContainer1);
			this.Name = "ServiceControlForm";
			this.Text = "Service Control";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.tableLayoutPanel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.ListBox listBoxServices;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.TextBox textDisplayName;
		private System.Windows.Forms.TextBox textServiceStatus;
		private System.Windows.Forms.TextBox textServiceType;
		private System.Windows.Forms.TextBox textServiceName;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private System.Windows.Forms.Button buttonStart;
		private System.Windows.Forms.Button buttonStop;
		private System.Windows.Forms.Button buttonPause;
		private System.Windows.Forms.Button buttonContinue;
		private System.Windows.Forms.Button buttonRefresh;
		private System.Windows.Forms.Button buttonExit;
	}
}

