﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceProcess;

#endregion

namespace ServiceControl
{
	partial class ServiceControlForm : Form
	{
		private System.ServiceProcess.ServiceController[] services;

		public ServiceControlForm()
		{
			InitializeComponent();
			RefreshServiceList();
		}

		private void RefreshServiceList()
		{
			services = ServiceController.GetServices();
			listBoxServices.DisplayMember = "DisplayName";
			listBoxServices.DataSource = services;

		}

		protected string GetServiceTypeName(ServiceType type)
		{
			string serviceType = "";
			if ((type & ServiceType.InteractiveProcess) != 0)
			{
				serviceType = "Interactive ";
				type -= ServiceType.InteractiveProcess;
			}
			switch (type)
			{
				case ServiceType.Adapter:
					serviceType += "Adapter";
					break;
				case ServiceType.FileSystemDriver:
				case ServiceType.KernelDriver:
				case ServiceType.RecognizerDriver:
					serviceType += "Driver";
					break;
				case ServiceType.Win32OwnProcess:
					serviceType += "Win32 Service Process";
					break;
				case ServiceType.Win32ShareProcess:
					serviceType += "Win32 Shared Process";
					break;
				default:
					serviceType += "unknown type " + type.ToString();
					break;
			}
			return serviceType;
		}

		protected void SetServiceStatus(ServiceController controller)
		{
			buttonStart.Enabled = true;
			buttonStop.Enabled = true;
			buttonPause.Enabled = true;
			buttonContinue.Enabled = true;
			if (!controller.CanPauseAndContinue)
			{
				buttonPause.Enabled = false;
				buttonContinue.Enabled = false;
			}
			if (!controller.CanStop)
			{
				buttonStop.Enabled = false;
			}
			ServiceControllerStatus status = controller.Status;
			switch (status)
			{
				case ServiceControllerStatus.ContinuePending:
					textServiceStatus.Text = "Continue Pending";
					buttonContinue.Enabled = false;
					break;
				case ServiceControllerStatus.Paused:
					textServiceStatus.Text = "Paused";
					buttonPause.Enabled = false;
					buttonStart.Enabled = false;
					break;
				case ServiceControllerStatus.PausePending:
					textServiceStatus.Text = "Pause Pending";
					buttonPause.Enabled = false;
					buttonStart.Enabled = false;
					break;
				case ServiceControllerStatus.StartPending:
					textServiceStatus.Text = "Start Pending";
					buttonStart.Enabled = false;
					break;
				case ServiceControllerStatus.Running:
					textServiceStatus.Text = "Running";
					buttonStart.Enabled = false;
					buttonContinue.Enabled = false;
					break;
				case ServiceControllerStatus.Stopped:
					textServiceStatus.Text = "Stopped";
					buttonStop.Enabled = false;
					break;
				case ServiceControllerStatus.StopPending:
					textServiceStatus.Text = "Stop Pending";
					buttonStop.Enabled = false;
					break;
				default:
					textServiceStatus.Text = "Unknown status";
					break;
			}

		}


		protected void OnSelectedIndexChanged(object sender, System.EventArgs e)
		{
			ServiceController controller =
						(ServiceController)listBoxServices.SelectedItem;
			textDisplayName.Text = controller.DisplayName;
			textServiceType.Text = GetServiceTypeName(controller.ServiceType);
			textServiceName.Text = controller.ServiceName;
			SetServiceStatus(controller);
		}

		protected void buttonCommand_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			ServiceController controller =
							  (ServiceController)listBoxServices.SelectedItem;
			if (sender == this.buttonStart)
			{
				controller.Start();
				controller.WaitForStatus(ServiceControllerStatus.Running);
			}
			else if (sender == this.buttonStop)
			{
				controller.Stop();
				controller.WaitForStatus(ServiceControllerStatus.Stopped);
			}
			else if (sender == this.buttonPause)
			{
				controller.Pause();
				controller.WaitForStatus(ServiceControllerStatus.Paused);
			}
			else if (sender == this.buttonContinue)
			{
				controller.Continue();
				controller.WaitForStatus(ServiceControllerStatus.Running);
			}
			int index = listBoxServices.SelectedIndex;
			RefreshServiceList();
			listBoxServices.SelectedIndex = index;
			Cursor.Current = Cursors.Default;
		}

		protected void buttonExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
		protected void buttonRefresh_Click(object sender, System.EventArgs e)
		{
			RefreshServiceList();
		}


	}
}