﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace test
{
	partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
	}
}